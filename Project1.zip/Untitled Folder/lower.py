#!/usr/bin/env python

"""
A filter that works like 'tr' command in unix shell.
"""

import fileinput


def process(line):
    """For each line of input, lower the case."""
    print(line[:-1].lower())


for line in fileinput.input():
    process(line)
