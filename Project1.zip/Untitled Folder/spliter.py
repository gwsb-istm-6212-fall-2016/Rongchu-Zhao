#!/usr/bin/env python

"""
A filter that split up the text lines into a word per line.
"""

import fileinput
"""For each line of input, split up into a word per line."""
"""In the meantime, ignoring thoes words include only one character."""
def process(line):
    for word in line.split():
        if len(word) <= 1:
            continue
        print (word.strip( ))
   
    

for line in fileinput.input():
    """For each line of input, replace all punctuations with a whitespace"""
    line = line.replace(',',' ')
    line = line.replace('.',' ')
    line = line.replace('?',' ')
    line = line.replace(':',' ')
    line = line.replace('!',' ')
    line = line.replace("'"," ")
    line = line.replace(';',' ')
    line = line.replace('"',' ')
    line = line.replace('-',' ')
    line = line.replace('(',' ')
    line = line.replace(')',' ')    
    line = line.replace('/',' ')
    line = line.replace('~',' ')
    line = line.replace('*',' ')
    line = line.replace('[',' ')
    line = line.replace(']',' ')
    line = line.replace('#',' ')
    line = line.replace('`',' ')
    line = line.replace('$',' ')
    line = line.replace('@',' ')   
    process(line)
