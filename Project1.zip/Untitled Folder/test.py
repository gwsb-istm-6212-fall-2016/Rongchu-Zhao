#!/usr/bin/env python

"""
A filter that removes 15 common words in a specific file.
"""

import fileinput
""" Here is the list that containts stop words that used in this filter"""

stopw = ['a','the','above','after','again','against','to','get','an','and','any','are','as','at','be']

"""Basically, this loop will not return the words that included in the stopw list"""

for line in fileinput.input():
    line = line.strip()
    if line in stopw:
        continue
    print(line)
